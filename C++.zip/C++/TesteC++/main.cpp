#include <iostream>

using namespace std;
char converterChar(char letra);
int quadrado(int numero);
char maiuscula(char ch);
char maiuscula(char ch);

int main()
{
    char vetCaracteres[] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'};
    int vetInteiros[] = {2, 1, 8, 10, 9, 4, 3, 1, 4, 6};
    for (int i = 1; i < 10; i ++)
        vetCaracteres[i] = maius

}
    char letra;
    cout << maiuscula(letra) << endl;
    cout << minuscula(letra) << endl;
char proxima(char ch) {
    if ( letra[i] <10) {
        return 0;
    }
    else {
        letra[i] = 1;
        return 1;
    }
}
char maiuscula(char ch) { return toupper(ch); }
char maiuscula(char ch) { return tolower(ch); }

char converterChar(char letra);
int quadrado(int numero) {
    return numero * numero;
}
cout << "letra: " << letra << endl;
