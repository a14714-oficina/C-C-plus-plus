#include <iostream>

using namespace std;
float contarAlturas180e190(int v[], int n);
float calcularMedia(float alturas[], int media);

int contarAlturas180e190(float alturas[], int media) {
int main()

float alturas[10] =  {1.65,1.66,1.67,1.68,1.69,1.70,1.71,1.72,1.73,1.74,1.75};
cout<<"Numero de alturas entre 1.80 e 1.90: "<<alturas(vet1,10);
    cout<<"M�dia de alturas: "<<mediaalturas(vet1,10);
}

float contarAlturas180e190(int v[], int n) {
    float num_alturas = 0;
    for(int i = 0, i < n; i++ ) {
        if (alturas[i] >= 1.80 && alturas[i] <= 1.90)
            num_alturas++
    }
    return num_alturas
}
float calcularMedia(float alturas[], int media) {
    float soma = 0;
    for (int i = 0; i < tamanho; i++) {
        soma += alturas[i];
    }
    return soma / tamanho;
}
    int tamanho = 10;
    float alturas[tamanho] = {1.70, 1.85, 1.78, 1.90, 2.00, 1.65, 1.88, 1.95, 2.05, 1.80};

    int quantidadeEntre180e190 = contarAlturasEntre180e190(alturas, tamanho);
    float media = calcularMedia(alturas, tamanho);

    cout << "Quantidade de alturas entre 1.80m e 1.90m: " << quantidadeEntre180e190 << endl;
    cout << "M�dia das alturas: " << media << "m" << endl;

    return 0;
}
