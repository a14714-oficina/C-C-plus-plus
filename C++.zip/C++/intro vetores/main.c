#include <stdio.h>
#include <stdlib.h>
#define INDICE 15

int main(){
    int indices[INDICE]; // 0 a 9
    int pares[INDICE];
    for(int i = 0; i < INDICE; i++) {
        printf("Indice %d\n", i);
    }

    // parar o programa
    system("PAUSE");
    // limpar a consola
    system("cls");
    printf("A consola foi limpa.\n");
    printf("\nDIGITAR OS PRIMEIROS 15 NUMEROS PARES\n\n");
    for(int i = 0; i<INDICE; i++) {
        int par;
        par = i * 2;
        pares[i] = par;
        printf("%d\n ", pares[i]);
    }
}
