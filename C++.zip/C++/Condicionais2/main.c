#include <stdio.h>
#include <stdlib.h>

int main()
{
    float nota;

    printf("digite uma nota: ");
    scanf("%f", &nota);

    if (nota < 8) {
        printf("Aluno reprovado");
    }
    else if (nota >= 10){
       printf("Aluno aprovado");
    }
   else {
    printf("Aluno deve recuperar");
   }
    printf("\n\nPROGRAMA TERMINADO\n");
}
