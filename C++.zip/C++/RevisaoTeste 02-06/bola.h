#ifndef BOLA_H_INCLUDED
#define BOLA_H_INCLUDED

#include <string.h>
using namespace std;

struct Tamanho{int largura; int altura; };
struct Bola {int peso; int diametro; string cor; Tamanho t; };

Bola novaBola(int peso, int diametro, string cor, Tamanho t) {
    Bola b;
    b.peso = peso;
    b.diametro = diametro;
    b.cor = cor;
    b.t.largura = t.largura;
    b.t.altura = t.altura;
    return b;
}

// Alterar uma propiedade do objeto (int) do objeto Bola
int alterarDiametro(Bola b, int novoDiametro) {
    return novoDiametro;
}
// Alterar uma propiedade do largura (int) do objeto Bola
int alterarLargura (Bola b, int novaLargura) {
    Bola bl;
    bl.t.largura = novaLargura;
    return bl.t.largura;
}
void listarDados(Bola b) {
    cout << "Dados da minha bola: " << endl << endl;
    cout <<"Peso: " << b.peso << "Kg" << endl;
    cout << "Diametro: " << b.diametro << "cm" << endl;
    cout << "Tamanho: " << b.t.largura << "x" << b.t.altura;

}

void tipoDaBola(Bola b) {
    if (b.diametro < 20) {
        cout << "Bola de Andebol" << endl;
    }
    else if (b.diametro > 30) {
        cout << "Bola de Basquetebol" << endl;
    }
    else {
        cout << "Bola de Futebol" << endl;
    }
}
int alterarAltura(Bola b, int valor) {
    return b.t.altura + valor;
}


#endif // BOLA_H_INCLUDED

