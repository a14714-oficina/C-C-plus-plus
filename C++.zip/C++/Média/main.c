#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
int main()
{
    int num1, num2;
    float media;


    setlocale(LC_ALL,"Portuguese");

    printf("Digite o primeiro valor: ");
    scanf("%d", &num1);
    printf("Digite o segundo valor: ");
    scanf("%d", &num2);

    media = (float) (num1 + num2) / 2;
    printf("A m�dia final � %.2f. \n", media);


}

