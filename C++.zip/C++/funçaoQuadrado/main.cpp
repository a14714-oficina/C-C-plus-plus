#include <iostream>
#include "quadrado.h"

using namespace std;

int main()
{
     Quadrado q, p;

     q.lado = 5;
     p.lado = 3;
     q.lado = AlterarLado(q,8);

     cout << CalcularPerimetro(q) << ", " << CalcularPerimetro(p);
}
