#include <stdio.h>
#include <stdlib.h>

int main()
{
    int matriz[4] [3];
    int valor = 1;
    //Percorrer cada Linha
    for (int i = 0; i < 4; i++) {
        // Percorrer cada Coluna
        for(int j = 0; j < 3; j++) {
           matriz[i] [j] = valor;
           ++valor;
           printf("%d\t", matriz[i] [j]);
           if (j == 2)
                printf("\n");
        }
    }
}
