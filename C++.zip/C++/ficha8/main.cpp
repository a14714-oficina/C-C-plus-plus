#include <iostream>

using namespace std;
int maiorNota(int v[], int n)
int positivas(int v[], int n)
int zero_ou_um(int n)

int main()

{
    int notas[15] =  {8,11,12,13,7,12,19,3,12,14,15,19,20,13,12,7};
    cout << "Numero de positivas : " << positivas(notas,15);
    cout << "Maior nota: " << maiorNota(notas,15);
    for ( int i = 0; i < 15; i++)
        notas[i] = zero_ou_um(notas[i);]
}


int positivas(int v[], int n) { // n � o n� de elementos do vetor
    int num_positivas = 0;
    for(int i = 0, i < n; i++ ) {
        if (v[i] >= 10)
            num_positivas = num_positivas + 1;
    }
    return num_positivas
}

int maiorNota(int v[], int n) {
    int maiorNota = 0;
    for (int i = 0; i < n; i++) {
        if (v[i] > maiorNota)
            maiorNota = v[i];
    }
    return maiorNota;
}

int zero_ou_um(int n) {
if (n >12)
    return 1;
else
    return 0;


}
