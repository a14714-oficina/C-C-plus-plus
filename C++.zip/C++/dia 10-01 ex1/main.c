#include <stdio.h>
#include <stdlib.h>

int main()
{
    int valores[10];
    int positivos= 0;
    for(int i = 0; i < 10; i++) {
        printf("Digite um valor:  ");
        scanf("%d", &valores[i]);

        if (valores[i] > 0)
        positivos++;
    }
    printf ("valor positivos: %d", positivos);
}
