#include <iostream>
#include "cores.h"

using namespace std;

int main() {
    Cor cor1 = criarCor(255, 100, 50);

    Quadro quadro1 = criarQuadro(100, 200, "The quadro", "Carlos", cor1);
    quadro1.C[0] = cor1;

    quadro1.C[0].verde = alterar(quadro1.C[0], 150);

    quadro1.largura = alterarLargura(quadro1, 120);
    quadro1.altura = alterarAltura(quadro1, 250);


    listarQuadro(quadro1);

    cout << "Cor (R, G, B): ("
         << quadro1.C[0].vermelho << ", "
         << quadro1.C[0].verde << ", "
         << quadro1.C[0].azul << ")" << endl;

    return 0;
}
