#ifndef CORES_H_INCLUDED
#define CORES_H_INCLUDED

#include <string.h>
using namespace std;

struct Cor {
    int vermelho, verde, azul;
};
struct Quadro {int largura; int altura; string nome; string autor; Cor C[3];};

Cor criarCor(int vermelho, int verde, int azul) {
    Cor c;
    c.vermelho = vermelho;
    c.verde = verde;
    c.azul = azul;
    return c;
}
Quadro criarQuadro(int largura, int altura, string nome, string autor, Cor cores){
    Quadro q;
    q.largura = largura;
    q.altura = altura;
    q.nome = nome;
    q.autor = autor;
    return q;
}

// Alterar o tom verde para outro valor
int alterar( Cor c, int novoTom) {
    return novoTom;
}
// Alterar o valor da Largura
int alterarLargura(Quadro q, int novaLargura) {
    return novaLargura;
}
// Alterar o valor da Altura
int alterarAltura(Quadro q, int novaAltura) {
    return novaAltura;
}
void listarQuadro(Quadro q) {
    cout << "Dados do meu quadro: " << endl << endl;
    cout << "Nome do quadro: " << q.nome << endl;
    cout << "Autor: " << q.autor << endl;
    cout << "Tamanho: " << q.largura << " x " << q.altura << endl;
}

#endif // CORES_H_INCLUDED
