#ifndef ESTRUTURAS_H_INCLUDED
#define ESTRUTURAS_H_INCLUDED

#include <string>
using namespace std;
typedef struct Carro {
    string matricula;
    string marca;
    string; modelo;
    int ano;
    float consumo_medio;
};
typedef struct Disciplina {
    string codigo;
    string nome_disciplina;
    int numero_horas;
    int ano;
};
typedef struct ContaBancaria {
    int numero_conta;
    string cliente;
    float saldo;
    string Gerente;
};

typedef struct Data {
    int Dia;
    int Mes;
    int Ano;
    int hora;
    int minuto;
};
typedef struct Jogador {
    string Username;
    string password;
    int nib;
    int nums[3];
};
typedef struct Reuniao {
    float id_reuniao;
    string local;
    Data data_reuniao;
    string lista[3];
};
typedef struct Aluno {
    int numero_aluno;
    int Data data_nascimento;
    int Disciplina disciplinas[3];
};
#endif // ESTRUTURAS_H_INCLUDED
