#include <stdio.h>
#include <stdlib.h>

int main()
{
    int v[10];
    int valor;

    printf("Digite 10 valores para preencher o vetor: \n");
    for(int j = 0; j <10; j++) {
        scanf("%d", &v[j]);
    }
   printf("\nDigite o valor a procurar no vetor: ");
   scanf("%d", &valor);

   for(int j = 0; j < 10; j++) {
    if (v[j]==valor) {
        printf("valor encotrado na posicao %d\n", j);
        return 0;
    }
   }
    printf("Valor nao encontrado!");
}
