#include <iostream>
#include "livros.h"
using namespace std;

int main()
{
    Livro livros[3];
    livros[0] = novoLivro(1,"Ana Maria","As Ondas","Crime",true);
    livros[1] = novoLivro(2,"Rui Daniel","Eu","Romance",false);
    livros[2] = novoLivro(3,"S� Caos","Ele","Crime",false);

    for (int i = 0; i < 3; i++) {
        mostrarDados(livros[i]);
    }
}
