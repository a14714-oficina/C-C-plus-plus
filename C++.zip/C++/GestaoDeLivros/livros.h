#ifndef LIVRO_H_INCLUDED
#define LIVRO_H_INCLUDED

#include <iostream>
#include <string>
#include <stdbool.h>
using namespace std;

struct Livro {
    int codigo;string autor;string titulo;string genero;bool alugado;
};

Livro novoLivro(int cdg, string aut,string tit, string gen, bool alg) {
    Livro lvr;
    lvr.codigo = cdg; lvr.autor = aut;
    lvr.titulo = tit; lvr.genero = gen;
    lvr.alugado = alg; return lvr;
}
void mostrarDados(Livro lvr) {
    cout << lvr.titulo << " com id " << lvr.codigo << " do autor ";
    cout << lvr.autor << " do genero " << lvr.genero << endl;
}

void exibirLivrosDoAutor(Livro lvr[], string autor_procurado,int elem)



#endif // LIVROS_H_INCLUDED
