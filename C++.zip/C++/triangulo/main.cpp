#include <iostream>

using namespace std;

typedef struct retangulo {
    int largura;
    int comprimento;
} retangulo;

void alterarLargura(int nova_largura, retangulo &r);
int perimetro(retangulo r);

int main() {
    retangulo ret, ret2;

    ret.largura = 10;
    ret.comprimento = 12;
    ret2.largura = 5;
    ret2.comprimento = 8;

    alterarLargura(20, ret2);

    cout << "Largura alterada: " << ret2.largura << endl;
    cout << "Per�metro = " << perimetro(ret2) << endl;

    return 0;
}

void alterarLargura(int nova_largura, retangulo &r) {
    r.largura = nova_largura;
}

int perimetro(retangulo r) {
    return 2 * (r.largura + r.comprimento);
}

