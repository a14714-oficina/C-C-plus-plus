#include <stdio.h>
#include <stdlib.h>

int main()
{
    int matriz[3][3] = {{2, 5, 8}, {-3, 0, 9}, {1, -5, 12}};
    int soma;
 //Percorrer cada Linha
    for (int i = 0; i < 4; i++) {
        // Percorrer cada Coluna
        for(int j = 0; j < 3; j++) {
           if(matriz[i][j]> 0 );
          soma = soma + matriz [i][j];
           printf("%d\t", soma);
}
    }
}
