#include <iostream>
using namespace std;
char proxima(char ch);
char anterior(char ch);
char maiuscula(char ch);
char minuscula(char ch);
int codigo(char ch);

int main()
{
    char letra;
    cout << "Digite uma letra a sua escolha: ";
    cin >> letra;
    cout << proxima(letra) << endl;
    cout << anterior(letra) << endl;
    cout << maiuscula(letra) << endl;
    cout << minuscula(letra) << endl;
    cout << codigo(letra) << endl;
}
char proxima(char ch) {
    if (toupper(ch) == 'Z')
        return ch;
    return ch + 1;
}
char anterior(char ch) { return ch - 1; }
char maiuscula(char ch) { return toupper(ch); }
char minuscula(char ch) { return tolower(ch); }
int codigo(char ch) { return  (int)ch; }

