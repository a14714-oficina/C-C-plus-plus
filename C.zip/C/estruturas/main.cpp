#include <iostream>
#include "estruturas.h"

using namespace std;

int main()
{
    Carro c1 = {"12-ST-11","Audi","A3",2021,4.23f};
    Carro c2 = novoCarro("12-ST-11","Audi","A3",2021,4.23f);
    Disciplina d1 = {"M4","Estruturas est�ticas", 30,2022};
    Data data_teste = {12,5,2025,15,30};
    Jogador jg = {"admin","123456",1234,{19,7,10}};
    ContaBancaria cb01 = {12345,"Vitoria",12345.12f,"Carlos"};
    ContaBancaria cb02 = novaConta(12345,"Vitoria",12345.11f,"Carlos"};

    cb02.saldo = alterarSaldo(cb02,10000);
    cout << cb02.saldo;
    cb01.saldo = depositar(cb01,200,0f);
    cb01.saldo = levantar(cb01,200,0f);
    cout << cb01.saldo;

}
