#ifndef ESTRUTURAS_H_INCLUDED
#define ESTRUTURAS_H_INCLUDED

#include <string>
using namespace std;
typedef struct Carro {
    string matricula;
    string marca;
    string modelo;
    int ano;
    float consumo_medio;
};
typedef struct Disciplina {
    string codigo;
    string nome_disciplina;
    int numero_horas;
    int ano;
};
typedef struct ContaBancaria {
    int numero_conta;
    string cliente;
    float saldo;
    string gerente;
};

typedef struct Data {
    int Dia;
    int Mes;
    int Ano;
    int hora;
    int minuto;
};
typedef struct Jogador {
    string Username;
    string password;
    int nib;
    int nums[3];
};
typedef struct Reuniao {
    float id_reuniao;
    string local;
    Data data_reuniao;
    string lista[3];
};
typedef struct Aluno {
    int numero_aluno;
    Data data_nascimento;
    Disciplina disciplinas[3];
};
// Inicializar uma conta banc�ria
ContaBancaria novaConta(int num, string cli, float sld, string ger) {
    ContaBancaria cb;
    cb.numero_conta = num;
    cb.cliente = cli;
    cb.saldo = sld;
    cb.gerente = ger;
    return cb;
};
// Inicializar uma conta banc�ria
Carro novoCarro(string matricula,string marca,string modelo,int ano,float consumo_medio) {
    Carro cr;
    cr.matricula = matricula;
    cr.marca = marca;
    cr.modelo = modelo;
    cr.ano = ano;
    cr.consumo_medio = consumo_medio;
    return cr;
};
float alterarSaldo(ContaBancaria cb, float novoSaldo) {
    return novoSaldo;
}

float depositar(ContaBancaria cb, float valor_deposito) {
    return cb.saldo + valor_deposito;
}

float levantar(ContaBancaria cb, float valor_levantamento) {
    if (cb.saldo < valor_levantamento) {
        cout << "Saldo insuficiente!" << endl;
        return cb.saldo;
    }
    else {
        return cb.saldo - valor_levantamento;
    }


}
#endif // ESTRUTURAS_H_INCLUDED

