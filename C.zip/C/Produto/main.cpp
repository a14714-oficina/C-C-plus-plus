#include <iostream>

using namespace std;

typedef struct Produto {
    int codigo; string nome; float preco; int iva;
};

float atualizarPreco(Produto pr, int aumento);

int main()
{
    Produto p;
    Produto q = {2, "Sal", 0.28, 6 };
    Produto bola;

    p.codigo = 1;
    p.nome = "Caramelo";
    p.preco = 2.23;
    p.iva = 13;

    cout << "O produto " << p.nome << " custa " << p.preco << " euros.";

    p.preco = atualizarPreco(p,18);
    cout << endl << "Novo preco:" << p. preco << endl;

    mostrarDados(p);
    mostrarDados(q);
}

float atualizarPreco(Produto pr, int aumento) {
    float novoPreco;
    novoPreco = pr.preco * (1 + (float)aumento/100);
    return novoPreco;
}

void mostrarDados(produtos pr) {
    cout << "Codigo: " << p.codigo << endl;
    cout << " Produto " << p.nome << endl;
    cout << "Preco: " << pr.preco << " euros " << endl;
    cout << " IVA: " << pr.iva << " % " << endl;
}
