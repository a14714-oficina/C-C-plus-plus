#include <stdio.h>
#include <stdlib.h>

int main()
{
    int num_dia;
    num_dia = 2;

    switch(num_dia) {
    case 1:
        printf("Domingo"); break;
    case 2:
        printf("Segunda"); break;
    case 3:
        printf("Terca"); break;
    default:
        printf("Dia da semana invalido");

    }
}
