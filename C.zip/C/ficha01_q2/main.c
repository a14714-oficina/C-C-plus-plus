#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
int main()
{
   float f, c;
   setlocale(LC_ALL,"Portuguese");
   printf("Digite um valor em Fahrenheit para Transformar em celsius: ");
   scanf("%f", &f);
    c = (5 * (f) / 9);
    printf("A temperatura em celsius %f � %f. \n",f,c);
}
