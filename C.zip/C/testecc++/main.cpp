#include <iostream>
#include <cctype>
using namespace std;

char converterChar(char letra);
int quadrado(int numero);
char maiuscula(char ch);
char minuscula(char ch);

int main() {
    char vetCaracteres[10] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'};
    int vetInteiros[10] = {2, 1, 8, 10, 9, 4, 3, 1, 4, 6};

    for (int i = 0; i < 10; i ++) {
        vetCaracteres[i] = maiuscula(vetCaracteres[i]);
        cout << vetCaracteres[i]
    }
    cout << endl;

    cout << "Vetor de inteiros: ";
    for(int i = 0; i < 10; i++) {
        vetInteiros[i] = quadrado(vetInteiros[i]);
        cout << vetInteiros[i]
    }

    return 0;
}

char maiuscula(char ch) {
    return toupper(ch);
}

char minuscula(char ch) {
    return tolower(ch);
}

int quadrado(int numero) {
    return numero * numero;
}
