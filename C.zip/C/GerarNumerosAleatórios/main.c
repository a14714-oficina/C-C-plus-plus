#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main()
{
    int aleatorios[5];

    srand(time(NULL));

    for(int i = 0; i < 5; i++) {
        // Gerar n�mero aleat�rio entre 1 e 100
        aleatorios[i] = rand() % 100 + 1;
        printf("%d\t", aleatorios[i]);
    }
    system("PAUSE");
    system("cls");
    for(int i = 0; i < 5; i++) {
        printf("Digite o valor %d: ", i+1);
        scanf("%d", &aleatorios[i]);
        }
        printf("\n\n\nValores inseridos:");
        for(int i = 0; i <5; i++) {
            printf("%d ", aleatorios[i]);
        }
}
