#include <iostream>
#include <cmath>
using namespace std;

int main() {
    float lado;
    cout << "digite um valor para  o lado do quadrado: ";
    cin >> lado;

   float perimetro = 4 * lado;
    float area = lado * lado;
    float diagonal = lado * sqrt(2);

    cout << "O perimetro do quadrado e: " << perimetro << endl;
    cout << "A �rea do quadrado e: " << area << endl;
    cout << "A diagonal do quadrado e: " << diagonal << endl;

    return 0;
}

