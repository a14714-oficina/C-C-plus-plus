#ifndef QUADRADO_H_INCLUDED
#define QUADRADO_H_INCLUDED

typedef struct Quadrado {
    int lado;
};

int CalcularPerimetro(Quadrado qr){
    return 4 * qr.lado;
}

int CalcularArea(quadrado qr ) {
    return qr.lado * qr.aldo;
}

int AlterarLado(Quadrado qr, int novoLado) {
    return novoLado;
}

#endif // QUADRADO_H_INCLUDED
