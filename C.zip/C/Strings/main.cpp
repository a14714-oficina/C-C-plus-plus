#include <iostream>
#include <cstring>
using namespace std;

int main()
{
    char nome1[40] = "Marcelo";
    char nome2[40] = "Amorim";
    char nome3[40] = "Marcelo";


    if (strcmp(nome1,nome2) == 1) {
        cout << "XXXXXXXX";
    }
    cout << endl;
    strcat(nome3,nome2);
    cout << nome3;
    strcpy(nomeCompleto,nome1);
    cout << endl;
    cout << nome1;
}
    // nomes iguais devolve 0
    // nomes diferentes ordenados alfabeticamente de forma asc -1
    // nomes diferentes ordenados alfabeticamente de forma desc -1

    // Strcmp comparar dois textos
    // StrCat juntar o texto de uma vari�vel com outra vari�vel
    // StrCopy copiar o conte�do de uma string para outra string.

