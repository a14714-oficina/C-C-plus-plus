#include <stdio.h>
#include <stdlib.h>

int main()
{
int origem[10] = {10,-3,8,11,9,-5,-7,19,18-3};
int destino[10];

    for (int i = 0; i < destino; i++) {
        if (origem[j] >= 0)
        destino[j] = origem[j];
        else
            destino[j] = origem[j] *(-2);
    printf("\n\n%d ", destino[j]);
}
