#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <locale.h>

int main()
{
    int v1[5], v2[5];
    int ganha_v1, ganha_v2;

    ganha_v1 = 0;
    ganha_v2 = 0;

    setlocale(LC_ALL, "Portuguese");
    srand(time(NULL));

     for (int j = 0; j < 5; j++) {
        v1[j] = rand() % 20 + 1;
        v2[j] = rand() % 20 + 1;
        printf("%d %d\n", v1[j], v2[j]);
        if(v1[j] > v2[j])
            ++ganha_v1;
        if(v2[j] > v1[j])
            ++ganha_v2;
    }
    printf("Resultado final: %d %d\n", ganha_v1, ganha_v2);
}
