#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
int main()
{
    int num, quadrado;
    setlocale(LC_ALL,"Portuguese");
    printf("********* QUADRADO DO NUM�RO *********\n\n");
    printf("Digite um valor: ");
    scanf("%d",&num);
    quadrado = num * num;
    printf("O quadrado de %d � igual a %d. \n",num,quadrado);
}
