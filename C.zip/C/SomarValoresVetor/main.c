#include <stdio.h>
#include <stdlib.h>
// Prot�tipo das fun�oes
int somarValores(int[], int);


int main()
{
   int nums[5] = {8,11,3,6,9};
   int nums2[8] = {23,11,45,6,7,8,4,12};
   int soma;
   soma = somarValores(nums2,8);
   printf("Soma do vetor nums = %d\n", soma);
}

int somarValores(int nums[], int num_elementos) {
    int s = 0;
    for (int j = 0; j < num_elementos; j++) {
        s = s + nums[j];
    }
    return s;
}
