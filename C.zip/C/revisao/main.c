#include <stdio.h>
#include <stdlib.h>

int main()
{
   int nums1[] = {4,8,11};
   int nums2[3];
   for (int j =0; j <3; j++) {
        printf("insira o elemento: %d ", j+1);
        scanf("%d", &nums2[j]);
   }
   system("cls");
   for (int j =0; j <3; j++) {
        printf("* %d\n", nums2[j]);
   }
}
