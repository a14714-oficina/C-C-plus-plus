#include <stdio.h>
#include <stdlib.h>

int main()
{
  int num;

  printf("digite um valor: ");
  scanf("%d", &num);

  if (num > 10 && num < 20) {
    printf("O valor %d esta dentro do intervalo.",num);
  }
  else {
    printf("O valor %d esta fora do intervalo.",num);
  }
}
