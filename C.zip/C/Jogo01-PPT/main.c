#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <locale.h>
#include <ctype.h>

int main()
{
    setlocale(LC_ALL,"Potuguese");
    srand(time(NULL));
    char pecas[] = {'P','T','S'}; // P- Papel, T- Tesoura, S- Pedra
    char pc, jogador;
    char jogar = 'S';
    int pontos_pc, pontos_jg;

    pontos_pc = 0;
    pontos_jg = 0;

    while (jogar == 'S') {
        // Pe�a do PC
        pc = pecas[rand() % 3];
        // Pe�a do jogador
        fflush(stdin);
        printf("Escolha (Papel(P), Tesoura(T), Pedra(S)) : ");
        scanf("%c", &jogador);

        if(pc == toupper(jogador)) {
            printf("Empate\n\n");
        }
        else {
           if ((pc=='P' && jogador=='S') ||(pc=='T' && (jogador=='P') ||(pc=='S' && jogador=='T')) {
                printf("Ganhou o PC\n\n");
                ++pontos_pc;
               }
           else {
                printf("Ganhou o Jogador\n\n");
                ++pontos_jg;
           }
        }
        printf("Saiu %c para o PC e %c para o jogador!\n", pc, jogador);
        printf("Resultado: Jogador %d x %d Pc\n", pontos_jg, pontos_pc);
        fflush(stdin);
        printf("Continuar a jogar(S/N)? ");
        scanf("%c", &jogar);
        system("cls"); // Limpar o ecr�
    }//Final do While
}

