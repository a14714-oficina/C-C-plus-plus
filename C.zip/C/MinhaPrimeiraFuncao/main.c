#include <stdio.h>
#include <stdlib.h>

int main()
{
    int soma,outrasoma,n1, n2,n3;

    n1 = 30;
    n2 = 20;
    soma = somarValores(n1,n2);
    dadosTurma();
    outrasoma = somarValores(n1,n3);
    printf("Soma = %d\n", soma);
}

int somarValores(int num1, int num2) {
    return num1 + num2;
}
void dadosTurma () {
    printf("Turma GPSI 1ANO\n");
    printf("Professor: Marcelo Amorim\n");
    printf("Total de Alunos: 20\n");
    printf("Aulas na sexta\n");
    printf("------------------------\n\n");
}

