#ifndef TRIANGULO_H_INCLUDED
#define TRIANGULO_H_INCLUDED
#include <math.h>

using namespace std;

struct Triangulo { int ld1; int ld2; int ld3; };

// Definir um tri�ngulo
Triangulo novoTriangulo(int lado1, int lado2, int lado3) {
    Triangulo tr;
    tr.ld1 = lado1;
    tr.ld2 = lado2;
    tr.ld3 = lado3;
    return tr;
}

int perimetro(Triangulo tr) {
    return tr.ld1 + tr.ld2 + tr.ld3;
}

float area(Triangulo tr) {
    float sp = (float) perimetro(tr) / 2;
    return sqrt(sp * (sp - tr.ld1) * (sp - tr.ld2) *(sp - tr.ld3));

}
int isTriangle(Triangulo tr) {
    if(tr.ld1 > tr.ld2+tr.ld3 || tr.ld2 > tr.ld1 + tr.ld3 || tr.ld3 > tr.ld1 + tr.ld2)
        return 0;
    return 1;
}

int tipo(Triangulo tr) {
    if(tr.ld1 == tr.ld2 && tr.ld2 == tr.ld3)
        return 0; // Equilatero
    else if (tr.ld1 != tr.ld2 && tr.ld2 != tr.ld3 && tr.ld1 != tr.ld2)
        return 2; // Escaleno
    else
        return 1; // Isosceles
}

int alterarLado1(Triangulo tr, int novoValor) {
    return novoValor;
}
#endif // TRIANGULO_H_INCLUDED
