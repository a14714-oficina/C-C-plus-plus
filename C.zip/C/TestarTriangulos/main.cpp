#include <iostream>
#include "triangulo.h"
using namespace std;

int main()
{
    Triangulo tri;

    tri = novoTriangulo(11,10,13);

    if (isTriangle(tri) == 0) {
        cout <<"Nao e possivel formar triangulo";
        return 0;

    }
    cout << "Perimetro = " << perimetro(tri) << endl;
    cout << "Area = " << area(tri) << endl;
    if (tipo(tri) == 0) {
        cout << "Triangulo Equilatero" << endl;
    }
    else if (tipo(tri == 1) {
        cout << "Triangulo Isosceles" << endl;
    }
    else {
        cout << "Triangulo Escaleno" << endl;
    }
}
