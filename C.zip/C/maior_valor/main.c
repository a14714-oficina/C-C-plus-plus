#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <locale.h>

int main()
{
  srand(time(NULL));
  setlocale(LC_ALL,"Portuguese");

  int aleatorios[10];
  int maior_valor = 0;

  // preencher o meu vetor aleat�rios
  for(int j = 0; j < 10; j++) {
    aleatorios[j] = rand() % 20 + 1;
    printf("%d",aleatorios[j]);
  }

  // detetar maior valor
  for(int j = 0; j < 10; j++) {
    if (aleatorios[j]>maior_valor)
        maior_valor = aleatorios[j];
  }
  printf("\nO maior valor � %d.\n", maior_valor);
}
