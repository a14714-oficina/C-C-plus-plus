#include <iostream>

using namespace std;
char pedirCaractere();
int converterChar(char c);
int totalVezesChar(char vc[], char c, int n);
int contarVogais(char vc[], int n);
int main()
{
    char vc [6], ch;
    int vi [5];

    for(int i = 0; i < 5; i++) {
        vc[i] = pedirCaractere();
        vi[i] = converterChar(vc[i]);
    }

     cout << endl << endl;

     for(int i = 0; i < 5; i++) {
        cout <<  vc[i] << "-" << vi[i] << endl;
    }
    cout << "Total de vogais: " << contarVogais(vc,5) << endl;
    cout << "Digite um caractere: ";
    cin >> ch;
    cout << "O caractere " << ch << " aparece " << totalVezesChar(vc,ch,5);
}

char pedirCaractere() {
    char c;
    cout << "Digite um caractere a sua escolha: ";
    cin >> c;
    return c;
}
int converterChar(char c) {
    int i;
    i = (int)c;
    return i;

}
int totalVezesChar(char vc[], char c, int n) {
    int total = 0;
    for (int i = 0; i < n; i++) {
        if (vc[i] == c)
            total++;
    }
    return total;
}
int contarVogais(char vc[], int n) {
    char vogais[] = { 'a','e','i','o','u'};
    int totalVogais = 0;

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < 5; j++) {
            if (tolower(vc[i]) == vogais[j]) {
                totalVogais++;
                break;
            }
        }
    }
    return totalVogais;
}
