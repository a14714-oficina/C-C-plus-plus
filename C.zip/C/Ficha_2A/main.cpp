#include <iostream>

using namespace std;

int main()
{
    int vet1[] = {1,3,5,7,9,11,2,8,15,12};
    int vet2[] = {3,2,8,11,9,10,8,13,10,20};
}
