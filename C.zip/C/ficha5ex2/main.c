#include <stdio.h>
#include <stdio.h>
int main() {
    int matriz[3][3] = {{2, 5, 8}, {-3, 0, 9}, {1, -5, 12}};
    int somaColuna[3];
    //Percorrer uma linha
    for (int i = 0; i < 3; i++) {
        somaColuna[i] = 0;
        //Percorrer cada  coluna
        for (int j = 0; j < 3; j++) {
            somaColuna[i] += matriz[j][i];
        }
        printf("A soma da coluna %d e: %d\n", i + 1, somaColuna[i]);
    }
}
