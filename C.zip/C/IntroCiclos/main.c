#include <stdio.h>
#include <stdlib.h>

int main()
{
    int soma = 0;
    printf("SA    I   SP\n");
    printf("---------------------------\n");
    for(int i = 0; i <= 10; i++) {
        printf("%2d + %2d = ", soma, i);
        soma = soma + i;
        printf("%2d\n", soma);
    }
    for (int i = 'A'; i <= 'Z'; i++) {
        printf("%d ", i);
    }
    int valor = 30;
    printf("\n\n");
    while (soma < 300) {
        soma += valor;
        printf("soma atual = %d (%d)\n", soma, valor);
        valor--;
    }
    int numeros [5];

    for (int i = 0; i<5; i++) {
        printf("Digite um valor: ");
    scanf("%d", &numeros[i]);
    }
    0   1   2    3   4
    8   11


}
