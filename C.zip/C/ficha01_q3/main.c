#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#define SALARIO 800.00
int main()
{
    float venda,comissao,sfinal;
    setlocale(LC_ALL,"Portuguese");
    printf("digite o total de vendas mensal: ");
    scanf("%f", &venda);
    comissao = venda * 0.15;
    sfinal = SALARIO + comissao;
    printf("o salario do trabalhador vai ser :%f\n",sfinal);

}
