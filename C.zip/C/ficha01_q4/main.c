#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <locale.h>
int main()
{
    float area,peri,raio;
    setlocale(LC_ALL,"Portuguese");
    printf("digite um valor para o raio: ");
    scanf("%f", &raio);
     peri = 2 * raio*M_PI;
    area = raio *pow (M_PI,2);
    printf("o perimetro da circunferencia � de %.2f\n, e a area � %.2f", peri,area);
}
