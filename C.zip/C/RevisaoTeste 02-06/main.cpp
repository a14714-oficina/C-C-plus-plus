#include <iostream>
#include "bola.h"
using namespace std;

int main()
{
    Bola minhaBola, minhaBola2;
    Tamanho tm = {10,20};

    minhaBola = novaBola(2,32,"Branca",{20,11});
    minhaBola2 = {3,42,"Vermelha", tm};

    minhaBola.t.largura = alterarLargura(minhaBola,35);
    minhaBola.diametro = alterarDiametro(minhaBola,22);
    listarDados(minhaBola2);
    cout << endl;
    tipoDaBola(minhaBola);
    tipoDaBola(minhaBola2);
    minhaBola.t.altura = alterarAltura(minhaBola,4);
    cout << "Nova altura da bola: " << minhaBola.t.altura;
}
