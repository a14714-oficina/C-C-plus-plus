#include <iostream>
#include <math.h>
using namespace std;
int perimetro(int ld);
int area (int ld);
float diagonal(int ld);

int main()
{
    int lado;
    int lados[5] = {3,7,5,9,2};

    for (int i = 0; i < 5; i++) {
        cout << "Perimetro = " << perimetro(lado) << endl;
        cout << "Area = " << area(lado) << endl;
        cout << "Diagonal = " << diagonal(lado) << endl;
        cout << endl;
    }
}
int perimetro(int ld) { return 4* ld; }
int area(int ld) {return ld * ld; }
float diagonal(int ld) {
    float dg;
    dg = sqrt(pow(ld,2) + pow(ld,2));
    return dg;
}

