#include <iostream>
#include <locale.h>

using namespace std;

int Menu();
int Somar(int num1, int num2);
int MaiorValor(int num1, int num2);
int decrementar (int num1);
float decrementar(int num1, float dec);

int main()
{
   int n1, n2, s, maior, opcaoMenu;
   float novoValor;
   n1 = 5;
   n2 = 7;
   setlocale(LC_ALL,"Portuguese");

   do {
        opcaoMenu = Menu();
        cout << endl;

        switch (opcaoMenu) {
            case 1:
                s = Somar(n1,n2);
                cout << "Soma = " << s << endl;
            case 2:
                    maior  = MaiorValor(n1,n2);
                    cout << "Maior valor = "<< maior << endl;
                    break;
            case 3:
                    n1 = decrementar(n1);
                    cout << "Novo valor de n1 = " << n1 << endl;
                    break;
            case 4:
                    novoValor = decrementar(n2,0.75);
                    cout << "Novo valor =" << novoValor << endl;
                    break;
            case 5:
                return 0;
                default:
                cout << "N�o ha esta op��o no menu. Tente novamente!";

            }
            system("PAUSE");
    } while (opcaoMenu != 5);
}

int Somar(int num1, int num2) {
    int soma;
    soma = num1 + num2;
    return soma;
}

int MaiorValor(int num1, int num2) {
        if (num1 > num2)
            return num1;
        else
            return num2;

}

int decrementar (int num1) {
    return num1 -1;
}

float decrementar(int num1, float dec){
    return num1 - dec;
}

int Menu() {
    int op;

    system("cls");
    cout << "menu" << endl;
    cout << "-----------------" << endl << endl;
    cout << "1- Somar valores" << endl;
    cout << "2- Maior valor" << endl;
    cout << "3- Diminuir em 1" << endl;
    cout << "4- Decrementar decimal" << endl;
    cout << "5- Sair do programa" << endl << endl;
    cout << "Escolha a sua op��o:";
    cin >> op;
    return op;
}
