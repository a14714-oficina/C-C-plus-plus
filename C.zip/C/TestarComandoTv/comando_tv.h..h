#ifndef COMANDO_TV_H__H_INCLUDED
#define COMANDO_TV_H__H_INCLUDED

using namespace std;

struct comando (string marca; int ano; int canal; int volume; bool ligar);

Comando novoComando (string mrc, int ano, int cn, int vl, bool lg) {
    Comando cm;
    cm.marca = mrc;
    cm.ano = ano;
    cm.canal = cn
    cm.volume = vl;
    cm.ligar = lg;
    return cm;
}
int trocarCanal(Comando cm, int novoCanal) {
    if (novoCanal >= 1 && novoCanal <= 99)
        return novoCanal;
    else
        return cm.canal;
}
int trocarVolume(Comando cm, char sinal) {
    if (sinal == '+') {
        if (cm.volume != 50)
            return cm.volume +1
        else
            return cm.volume;
    }
    else {
        if (cm.volume != 0)
            return cm.volume - 1;
        else
            return cm.volume;
    }
}
int tirarSom(Comando cm) {return 0;}








#endif // COMANDO_TV_H__H_INCLUDED
